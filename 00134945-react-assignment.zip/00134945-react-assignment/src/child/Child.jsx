import React from 'react'

const { onAdd, onSubtract, onMultiply, result } = props;

  return (
    <div>
      <button onClick={onAdd}>Add (+)</button><br />
      <button onClick={onSubtract}>Subtract (-)</button><br />
      <button onClick={onMultiply}>Multiply (*)</button><br />
      {result !== '' && <div>Result: {result}</div>}
    </div>
  );
