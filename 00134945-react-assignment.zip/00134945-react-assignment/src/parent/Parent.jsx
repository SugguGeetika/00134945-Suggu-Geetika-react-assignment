import React from 'react'

export default function ParentChildOperations() {
  const [a, setA] = useState('');
  const [b, setB] = useState('');
  const [result, setResult] = useState('');

  const handleA = (event) => {
    setA(event.target.value);
  };

  const handleB = (event) => {
    setB(event.target.value);
  };

  const add = () => {
    setResult(+a + +b);
  };

  const subtract = () => {
    setResult(+a - +b);
  };

  const multiply = () => {
    setResult(+a * +b);
  };

  return (
    <div>
      <input type="text" placeholder="Enter A" onKeyUp={handleA} /><br />
      <input type="text" placeholder="Enter B" onKeyUp={handleB} /><br />
      <button onClick={add}>Add (+)</button><br />
      <button onClick={subtract}>Subtract (-)</button><br />
      <button onClick={multiply}>Multiply (*)</button><br />
      {result !== '' && <div>Result: {result}</div>}
    </div>
  );
}
