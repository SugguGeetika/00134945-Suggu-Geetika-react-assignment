import React from 'react'

export default function Task1() {
  return (
    <div>Hello React!!!</div>
  )
}
